<!-- BEM tree -->
<!-- Objects -->
Card1
Card2
Card3

<!-- Global -->
CardContainer
    CardContainer-card / Card1 (x3)
        CardContainer-card-circle
        CardContainer-card-h2
     CardContainer-card-content
        CardContainer-card-button   