Box
    Box-card
        Box-card-figure
            Box-card-figure-img
        Box-card-content
            Box-card-content-h2