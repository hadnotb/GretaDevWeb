Header
    Header-logoBox
        Header-logoBox-img
        Header-logoBox-name
    Header-menu
        Header-menu-link
        Header-menu-userMenu
        -----> UserMenu
            UserMenu-userBox
                UserMenu-userBox-img
            UserMenu-wrap
                UserMenu-nav
                    UserMenu-nav-item
                        UserMenu-nav-item-link
                            UserMenu-nav-item-icon
